<section
    <?php echo e($attributes->merge(['class' => "w-full max-w-7xl mx-auto p-4 sm:p-14 border-x border-dashed border-neutral-300 dark:border-white/[9%]"])); ?>

>
    <?php echo e($slot); ?>

</section>
<?php /**PATH C:\Users\Hossein\Desktop\golestani-export-new\golestani\backup\phase-1\api\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/section-container.blade.php ENDPATH**/ ?>